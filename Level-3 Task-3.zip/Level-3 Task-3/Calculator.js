let expression = "";

function press(key) {
  expression += key;
  document.getElementById("display").innerText = expression;
}

function calculate() {
  try {
    const result = eval(expression);
    document.getElementById("display").innerText = result;
    expression = result.toString();
  } catch {
    document.getElementById("display").innerText = "Error";
    expression = "";
  }
}
